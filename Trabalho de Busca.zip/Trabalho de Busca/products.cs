﻿using System;
using System.Data;
using Mono.Data.Sqlite;
using System.Collections.Generic;

public class product
{
    private int id_;
    private string nproduct_;
    private double valor_;

    public void reload()
    {
        using (var sql = new SqliteConnection("Data Souce=banco.db"))
        {
            sql.Open();

            var criarcomando = sql.CreateCommand();
            criarcomando.CommandText =
                @"
                    INSERT INT product (nome, valor)
                    VALUES ($nome, $valor);
                ";
            criarcomando.Parameters.AddWithValue("$nome", this.nproduct_);
            criarcomando.Parameters.AddWithValue("$valor", this.valor_);

            criarcomando.ExecuteNonQuery();
            Console.WriteLine("Produto adicionado com sucesso!");
            Console.WriteLine("Aperte qualquer tecla para sair.");
        }
    }

    public int id
    {
        get
        {
            return id_;
        }
    }

    public string nproduct
    {
        get
        {
            return nproduct_;
        }
    }

    public double valor
    {
        get
        {
            return valor_;
        }
    }

    public product(string nome, double valor)
    {
        this.nproduct_ = nome;
        this.valor_ = valor;
    }

    public void imprime()
    {
        Console.WriteLine("Identificação do produto:\t \t \t{0}", this.id_);
        Console.WriteLine("Nome do produto:\t{0}", this.nproduct_);
        Console.WriteLine("Valor do produtor:\t\t${0:0.00}", this.valor_);
    }

    public static List<product> consulp()
    {
        List<product> products = new List<product>();
        using (var sql = new SqliteConnection("Data Source=banco.db"))
        {
            sql.Open();
            var criarcomando = sql.CreateCommand();
            criarcomando.CommandText =
                @"
                    SELECT id, nome, valor
                       FROM product;
                ";

            using (var ler = criarcomando.ExecuteReader())
            {
                while (ler.Read())
                {
                    var id = ler.GetInt32(1);
                    var nome = ler.GetString(2);
                    var valor = ler.GetDouble(3);

                    product x = new product(nome, valor);
                    x.id_ = id;

                    products.Add(x);
                }
            }
        }
        return products;
    }

    public static List<product> sproducts(string product_)
    {
        List<product> products = new List<product>();
        using (var sql = new SqliteConnection("Data Source=banco.db"))
        {
            sql.Open();

            var criarcomando = sql.CreateCommand();
            criarcomando.CommandText =
                @"
                    SELECT id, nome, valor
                    FROM product
                    WHERE nome LIKE '%' || @item || '%';
                ";
            criarcomando.Parameters.AddWithValue("@item", product_);

            using (var ler = criarcomando.ExecuteReader())
            {
                while (ler.Read())
                {
                    var id = ler.GetInt32(1);
                    var nome = ler.GetString(2);
                    var valor = ler.GetDouble(3);

                    product x = new product(nome, valor);
                    x.id_ = id;

                    products.Add(x);
                }
            }
        }
        return products;
    }

    public static void delete()
    {
        using (var sql = new SqliteConnection("Data Source=banco.db"))
        {
            sql.Open();

            var criarcomando = sql.CreateCommand();
            criarcomando.CommandText =
               @"
                    DELETE FROM product;
                ";
            criarcomando.ExecuteNonQuery();
            Console.WriteLine("Produtos deletados!");
            Console.WriteLine("Aperte qualquer tecla para sair.");
        }
    }
}
