﻿using System;
using Mono.Data.Sqlite;
using System.Collections.Generic;

class programa
{
    public static void Main(string[] args)
    {
        bool menu = true;
        while (menu)
        {
            menu = mprincipal();
        }
    }

    private static bool mprincipal()
    {
        var key == Console.ReadLine();
        Console.Clear();
        Console.WriteLine("Digite '1' para acessar a lista de produtos");
        Console.WriteLine("Digite '2' para cadastrar seu produto");
        Console.WriteLine("Digite '3' para excluir os produtos");
        Console.WriteLine("Digite '4' para procurar por um produto");
        Console.WriteLine("Digite '5' para Sair");

        if(key == "1")
        {
            verlista();
            Console.Read();
            return true;
        }

        if(key == "2")
        {
            cadastro();
            Console.Read();
            return true;
        }

        if(key == "3")
        {
            delete();
            Console.Read();
            return true;
        }

        if(key == "4")
        {
            procurando();
            Console.Read();
            return true;
        }

        if(key == "5")
        {
            Console.Clear();
            Console.WriteLine("Encerrando programa!");
            return false;
        }

        if(key == default)
        {
            return true;
        }

    }
    public static void procurando()
    {
        Console.Clear();
        Console.WriteLine("O que deseja procurar?");

        string procurar = Console.ReadLine();

        Console.Clear();
        Console.WriteLine("Mostrando Resultados da procura: {0}", procurar);

        List<product> products = product.sproducts(procurar);
        foreach (var product in products)
        {
            product.imprime();
        }
        Console.WriteLine("Aperte qualquer tecla para voltar");
    }

    public static void cadastro()
    {
        Console.WriteLine("Cadastrar produto");
        Console.WriteLine("Nome do produto: ");
        string nome = Console.ReadLine();
        Console.WriteLine("Valor do produto: ");
        double valor = Convert.ToDouble(Console.ReadLine());
        product x = new product(nome, valor);
        x.reload();
    }

    public static void verlista()
    {
        List<product> products = products.consulp();
        foreach (var product in products)
        {
            product.imprime();
        }
        Console.WriteLine("Aperte qualquer tecla para voltar");
    }
}